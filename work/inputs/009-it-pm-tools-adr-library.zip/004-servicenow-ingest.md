# ADR 004 — ServiceNow ingest approach

**Date**: 25.03.2026
**Status**: Accepted
**Scope**: repo-wide

---

## Context

DEC-005 (initiative management repo) established ServiceNow as the
portfolio-visibility layer. No API access is available (neither test nor
production instance), so any integration must work without it.

A ServiceNow saved report exists that lists the user's projects/initiatives.
It can be exported from the UI on demand. The JSON table export
(`pm_project` → right-click → *Export* → *JSON*) contains the full record:
all reference sys_ids, all narrative fields, and all metadata. A CSV export
is also available but provides only a narrow, user-configured view with
display-name column headers — it omits most fields.

---

## Decision

### New tool: `tools/servicenow-ingest/`

A dedicated tool reads the ServiceNow JSON export and writes a normalised,
dated Excel snapshot. This closes the **read direction** — it does not replace
the planned `tools/servicenow-stub/`, which handles the write direction
(rendering a field block for manual record creation).

**Input**: JSON export from the ServiceNow UI (path passed as CLI argument).
JSON is the canonical input because it preserves the full record including the 
narrative fields and sys_ids (needed to construct direct record URLs) that are 
absent from the CSV view.

**Output**: Excel file (`.xlsx`). Rationale: easy to inspect and share without
tooling; row count (< 100 initiatives) makes a database unnecessary.
Default output path: `outputs/servicenow-snapshot-<YYYY-MM-DD>.xlsx`.

**Temporary by design**: this tool exists because no API access is available.
Once a ServiceNow API connection is established, the read direction should be
replaced with a direct API call and this tool retired.

### `tools/servicenow-stub/` status

Deprioritized but not removed. It remains the planned mechanism for rendering
a ServiceNow field block from an INI file when a new record must be created
manually. To be implemented after `publish-initiative` is stable, or deferred
until API access is available.

---

## Consequences

- No credentials required for ingest — input is a local file. `SERVICENOW_BASE_URL`
  is read from `.env` only to construct direct record URLs from `sys_id`.
- Excel output requires `openpyxl`.
- Output files must be excluded from version control (`outputs/servicenow-snapshot-*.xlsx`).
- When API access becomes available, this tool should be retired in favour of
  a direct pull.
