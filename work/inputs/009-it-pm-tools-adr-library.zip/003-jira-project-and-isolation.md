# ADR 003 — Jira project and isolation strategy

**Date**: 25.03.2026
**Status**: Accepted
**Scope**: repo-wide

---

## Context

DEC-005 (initiative management repo) established Jira as the execution-tracking
layer, with one Epic per initiative phase. At that time the specific Jira project
was not determined.

The designated project is now confirmed: **IT-Architecture** (team-managed).

Key constraints that shape the isolation approach:

- **Shared project**: other team members' issues live in the same project.
  The API must not modify or inadvertently read issues it did not create.
- **Team-managed**: custom fields can be added. Owner has admin rights.
- **API scope**: `publish-initiative` is the only tool writing to Jira. All
  other tools are read-only at most.

---

## Decision

### Project key

Use the **IT-Architecture** project. Confirm the exact key via
`GET /rest/api/3/project` on varoenergy.atlassian.net, then record it below
and in `.env` as `JIRA_PROJECT_KEY`.

**Confirmed key**: `ITARCH`

### Isolation: three-layer approach

All issues created by `publish-initiative` carry:

1. **Custom field `Initiative ID`** (type: text, e.g. `INI-001`). Add this
   field to the IT-Architecture project before the first API run. It is the
   primary identifier — visible in the Jira UI and filterable in JQL.

2. **Label `ini-managed`**. Applied at creation. Serves as a safety belt: any
   JQL query or update operation from this tooling always includes
   `labels = "ini-managed"` in its filter.

3. **Back-reference in the INI file**. Created issue keys are written back to
   the `Jira Epics` field in the relevant `INI-xxx.md`. The API uses these
   stored keys for direct access — it never searches for "our" issues
   speculatively; it only touches keys it already knows about.

### Enforcement in `lib/jira.py`

- `create_epic` and `create_story` always set the `Initiative ID` field and
  the `ini-managed` label. No opt-out.
- `update_issue` (if added later) verifies the `ini-managed` label is present
  on the target issue before proceeding; raises `PermissionError` if not.
- No bulk-update or bulk-delete functions. Destructive operations are
  issue-key-explicit only.

---

## Consequences

- The `Initiative ID` custom field is created in the IT-Architecture project.
  Field ID: `customfield_10422`. JQL clause name: `"Initiative ID[Short text]"`.
  Set `JIRA_INITIATIVE_FIELD_ID=customfield_10422` in `.env`.
- `lib/jira.py` credentials: `JIRA_BASE_URL`, `JIRA_EMAIL`, `JIRA_API_TOKEN`,
  `JIRA_PROJECT_KEY`, `JIRA_INITIATIVE_FIELD_ID`.
- JQL pattern for "all our Epics": `project = <key> AND labels = "ini-managed"
  AND issuetype = Epic ORDER BY created DESC`.
