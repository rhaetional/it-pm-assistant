# 001 — Repository layout: tools/ + lib/ + templates/

## Problem

Multiple independent scripts sharing the same Confluence API credentials and transport
code had no shared home, causing auth logic to be duplicated across each file.

## Context

The repo started as a flat collection of one-off scripts at the root level
(`fetch_page.py`, `sync_page_properties.py`, `jde-functional-design.md`).
A second tool was already planned (batch processing), and more are expected.
Python packaging was not a goal — scripts are run directly from the venv.

## Decision

The repo is structured as:

- `lib/confluence.py` — single source of truth for auth, HTTP transport, and
  the three core API operations (`fetch_page`, `get_children`, `update_page`).
- `tools/<tool-name>/` — one directory per script, each containing the script
  and a `README.md`. Tool dirs use hyphens (shell-friendly); script files use
  underscores (Python-friendly).
- `templates/` — config masks and page-type templates used by tools but
  belonging to the domain, not to any single tool.
- `docs/decisions/` — repo-wide ADRs (this file).
- `tools/<tool-name>/decisions/` — tool-specific ADRs.
- `seed/` — reference material and vendor proposals; not executed.

Each tool adds the repo root to `sys.path` at startup so `lib` is importable
without packaging:
```python
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from lib.confluence import fetch_page, update_page
```

## Rationale

A `src/` layout with a proper installable package was considered and rejected:
`pip install -e .` conflicts with Homebrew-managed Python on macOS and adds
packaging ceremony that provides no benefit when scripts are always run from
the venv directly. The `sys.path.insert` approach is explicit, reproducible,
and requires zero build tooling.

`lib/` was chosen over `shared/` or `common/` because it matches the mental
model of "a library imported by tools", and is the conventional name in Python
projects that are not themselves packages.

The `.gitignore` previously excluded `lib/` as a packaging artefact — this
was corrected when the layout was adopted.

## Evidence

Type: Implemented & tested

All three existing scripts (`fetch_page.py`, `sync_page_properties.py`) were
moved into the new layout and verified to import correctly from `lib.confluence`
with the venv active.

## Review Triggers

- A third tool needs to share non-API logic (e.g. XML utilities) that doesn't
  belong in `lib/confluence.py` — evaluate adding `lib/xml_utils.py` or a
  sub-package.
- The team grows beyond 1–2 people and a proper installable package becomes
  worth the friction.

## Affected Files

`lib/__init__.py` — new
`lib/confluence.py` — new
`tools/fetch-page/fetch_page.py` — new (replaces root `fetch_page.py`)
`tools/fetch-page/README.md` — new
`tools/sync-page-properties/sync_page_properties.py` — new (replaces root `sync_page_properties.py`)
`tools/sync-page-properties/README.md` — new
`templates/jde-functional-design.md` — new (replaces root `jde-functional-design.md`)
`docs/decisions/` — new
`.gitignore` — `lib/` entry commented out
`README.md` — rewritten
