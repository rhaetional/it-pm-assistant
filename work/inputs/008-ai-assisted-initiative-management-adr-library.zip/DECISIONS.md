# Decision Log — Index

Decisions about the structure, conventions, and tooling of this repository.
Not for decisions about the content of individual initiatives.

Each decision lives in its own file. This index is the entry point.
Format: newest first.

| ID | File | Summary |
|----|------|---------|
| DEC-009 | [DEC-009-ini-schema-v2-execution-artefacts.md](DEC-009-ini-schema-v2-execution-artefacts.md) | Add `## Phases` section; rename `## Notes / Next Actions` → `## Staging`; one Epic per INI; Phase 0 — Staging is tool-owned |
| DEC-008 | [DEC-008-status-transition-criteria.md](DEC-008-status-transition-criteria.md) | Gate criteria for each status transition; Blocked is Active-only; Jira leads execution, ServiceNow is informational |
| DEC-007 | [DEC-007-branching-convention.md](DEC-007-branching-convention.md) | One branch per change; `<scope>/<nnn>-<slug>` naming; per-scope sequence numbers; individual decision files |
| DEC-006 | [DEC-006-jira-project-and-servicenow-ingest.md](DEC-006-jira-project-and-servicenow-ingest.md) | IT-Architecture Jira project confirmed; three-layer isolation; ServiceNow ingest via CSV export |
| DEC-005 | [DEC-005-four-layer-tooling-architecture.md](DEC-005-four-layer-tooling-architecture.md) | Four-layer model: this repo (planning), ServiceNow (portfolio), Jira (execution), Confluence (docs) |
| DEC-004 | [DEC-004-codex-toolchain.md](DEC-004-codex-toolchain.md) | Toolchain consolidated to Codex in VS Code; `generate-context.sh` retained as fallback |
| DEC-003 | [DEC-003-agent-bootstrap-entry-point.md](DEC-003-agent-bootstrap-entry-point.md) | `AGENTS.md` is the mandatory first read for every agent session |
| DEC-002 | [DEC-002-decision-log-scope.md](DEC-002-decision-log-scope.md) | Scope boundaries: repo decisions here; initiative decisions in INI files; arch decisions in Confluence ADRs |
| DEC-001 | [DEC-001-standalone-repo.md](DEC-001-standalone-repo.md) | Standalone repo over subdirectory; cross-references by link |
