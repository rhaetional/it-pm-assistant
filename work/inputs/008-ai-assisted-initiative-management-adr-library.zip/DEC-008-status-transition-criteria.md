# DEC-008 — Status transition criteria

**Date**: 26.03.2026
**Status**: Accepted

## Context

The initiative schema defines five statuses — Draft, Scoping, Active, Blocked,
Done — but no criteria governed when an initiative could move between them.
This meant transitions were implicit and inconsistent, making it hard for
agents and reviewers to assess whether a given status was accurate.

Two constraints shaped the decision:
- Jira is the execution system of record; ServiceNow is for portfolio
  visibility and budgeting. ServiceNow records are maintained manually and
  kept minimal — they do not gate initiative transitions.
- Blocked is reserved for Active initiatives. Draft and Scoping initiatives
  with unresolved gaps remain in their current status; the gaps are tracked
  in Risks & Gaps and Notes / Next Actions.

## Decision

### Draft → Scoping

All four must be true:

1. Problem Statement is specific and falsifiable — not "we should improve X"
2. Scope section has a first-cut In/Out list
3. Success Criteria drafted (rough is acceptable)
4. Deliberate go-signal: a sponsor or owner has decided this is worth
   investing time to define

Owner may still be TBD at this point — confirming ownership is often part
of scoping, not a prerequisite for it.

---

### Scoping → Active

All five must be true:

1. **Owner named** — a specific person, not a team or role
2. **Risks & Gaps cleared** — every open item either resolved or explicitly
   accepted with a mitigation note in the file
3. **Effort estimate set** — T-shirt sizing is sufficient
4. **Phases or workstreams defined** — sufficient to create Jira Epics
5. **Jira Epics created** — or Epic creation is the documented first action
   immediately following the transition; the INI file's `Jira Epics` field
   must be populated before the initiative is considered fully Active

ServiceNow record: update if one exists; creation is not required to go
Active.

---

### Active → Done

All three must be true:

1. **All Success Criteria met** — each criterion is written as a measurable
   outcome; verify against current state
2. **Notes / Next Actions cleared** — no outstanding items, or residual items
   explicitly deferred to a follow-on INI (note the INI ID) or documented
   as accepted out-of-scope
3. **ServiceNow record updated** — if a record exists, close it or initiate
   closure; if none exists, no action required

---

### Active → Blocked

All three must be stated in the file:

1. **Blocker named** — specific external dependency, decision, or person
2. **Blocker owner identified** — who is responsible for resolving it
3. **Expected resolution date noted** — an estimate is acceptable

Blocked applies to Active initiatives only. Scoping initiatives with
unresolved gaps remain Scoping.

### Blocked → Active

1. **Blocker removed** — add a note documenting what changed
2. **First action defined** — at least one concrete next step to resume

---

## Rationale

Grounding the criteria in what the existing Active initiatives (INI-004,
INI-012) already satisfy ensures they are not retroactively invalidated.
INI-004 has owner, phases, and ServiceNow record; INI-012 has owner, phases,
and concrete next actions — both meet the Scoping → Active bar.

Keeping Blocked Active-only avoids conflating "still being scoped" with
"was executing and hit a wall." The distinction matters for weekly review:
a Blocked initiative needs active unblocking effort; a slow-Scoping
initiative just needs its gaps resolved.

ServiceNow is deliberately excluded as a gate because it is maintained
manually for visibility and budgeting, not as an execution signal. Jira
Epics serve that role.

## Consequences

- AGENTS.md gains a `## Status Transitions` quick-reference section.
- At next review: INI-012's `ServiceNow Record` field should be reviewed —
  it is blank; either a record exists and needs linking, or N/A should be
  noted explicitly.
- INI-011 is close to Scoping-ready; the remaining gate is a go-signal from
  a sponsor or owner.
