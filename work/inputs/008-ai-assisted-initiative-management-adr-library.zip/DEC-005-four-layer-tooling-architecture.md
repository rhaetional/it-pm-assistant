# DEC-005 — Tooling ecosystem architecture: four-layer model

**Date**: 23.03.2026
**Status**: Accepted

## Context

Initiatives were tracked solely in markdown files in this repo, creating a silo.
Execution tasks, portfolio visibility, and documentation artefacts all lived in
the INI files with no integration to the systems used operationally (ServiceNow,
Jira, Confluence). This creates copy-paste maintenance burden and reduces
visibility to stakeholders.

## Decision

A four-layer model with a clear owner per layer:

| Layer | System | Owns |
|---|---|---|
| Planning / Scoping | This markdown repo | Initiative intent, scope, risks, success criteria — source of truth |
| Portfolio visibility | ServiceNow | Top-level initiative record + phases |
| Execution tracking | Jira | Shared Space → one Epic per phase → Stories/Tasks |
| Documentation | Confluence | Personal space → Initiatives/ → one page tree per INI |

**ServiceNow**: No API access currently. Integration is a manually maintained
record, populated from a rendered template generated from the INI file. The
template tool will be built with a stubbed `--push` flag so that when API access
arrives (test instance first), only the transport layer needs wiring — the data
model is fixed now. Tool will live in `atlassian-api-tools` as
`tools/servicenow-stub/`.

**Jira**: One shared organisational Space (cannot create per-initiative spaces).
Epics map to initiative phases; Stories/Tasks map to action items. Jira is
authoritative for execution status once an initiative is Active. API access is
available; integration via `atlassian-api-tools`.

**Confluence**: Personal space as workbench. Page hierarchy:
`Personal Space / Initiatives / INI-xxx — Title`. Documentation artefacts are
authored here and promoted (moved) to their permanent domain space (Architecture
& Systems, Engineering Hub, etc.) when mature. The personal space is not a
permanent home. Pages carry categorisation metadata (domain, TOGAF layer — TBC)
to guide promotion. The personal Initiatives folder does not attempt to mirror
the target taxonomy — that is the domain spaces' concern. API access available;
existing `atlassian-api-tools` Confluence tooling is extended.

**Status ownership**: ServiceNow holds portfolio-level status (Active, Blocked,
Done). Jira holds task-level status. The INI file `**Status**` field reflects
the planning lifecycle (Draft → Scoping → Active → Done) and is kept in sync
manually on transition.

## Consequences

- INI schema gains three back-link fields: `ServiceNow Record`, `Jira Epics`,
  `Confluence Page` — populated on transition to Active.
- `atlassian-api-tools` gains `lib/jira.py` and Jira-related tools.
- The INI file is a planning artefact; it does not track execution detail.
  Agents in Execute Mode read the INI for context but direct task work to Jira.
- The markdown repo remains the AI-assisted planning environment (Intake,
  Review, Execute modes unchanged).
