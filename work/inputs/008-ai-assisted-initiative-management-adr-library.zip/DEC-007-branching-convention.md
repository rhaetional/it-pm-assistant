# DEC-007 — Branching convention

**Date**: 25.03.2026
**Status**: Accepted

## Context

Without a naming convention, branches accumulate with no direct link to the
decision or initiative work they introduce. The `atlassian-api-tools` repo
established a convention (ADR 002) that proved immediately useful: given a
branch name you can locate the relevant decision doc without searching, and
vice versa. The same principle applies here.

This decision also migrates the decision log from a single `decisions/DECISIONS.md`
file to individual files per decision, which is required for the branch-name =
doc-path property to hold.

## Decision

**One branch per cohesive change, named after the decision doc or work item it
introduces.**

### Naming

```
<scope>/<nnn>-<slug>
```

| Part | Value |
|------|-------|
| `scope` | `decisions` for repo/process changes; `INI-xxx` for initiative-specific work (e.g. `INI-001`, `INI-002`) |
| `nnn` | Next unused three-digit number **within that scope** — matches the decision file number exactly |
| `slug` | Kebab-case matching the decision filename; or a descriptive slug if no decision file is created |

Examples:

```
decisions/007-branching-convention       ← this branch
INI-001/001-initial-scoping
INI-001/002-phase-1-kickoff
INI-003/001-cmdb-disambiguation
```

### When to branch

Branch for:
- Any repo/process change that warrants a DEC record
- Substantive initiative milestones: first full draft of an INI file, a status
  transition, a major scope change

Commit directly to `main` for:
- Incremental initiative edits: status note additions, updating Next Actions,
  minor wording fixes
- Registry updates that follow directly from work already branched

The test: would a future agent or reviewer benefit from seeing this change
isolated? If yes, branch.

### Decision log: individual files

Each decision lives in its own file: `decisions/DEC-nnn-slug.md`. The file
`decisions/DECISIONS.md` is an index only — it carries a one-line entry per
decision and links to the individual file.

Per-scope sequence numbers: `decisions/` and each `INI-xxx/` scope number
independently from `001`. No global renumbering when a new initiative is added.

### Lifecycle

1. `git checkout -b <scope>/<nnn>-<slug>` from current `main`.
2. Decision doc, INI file changes, registry update, and `AGENTS.md` update all
   land on the same branch.
3. `git merge --no-ff` into `main` to preserve the branch boundary.
4. Delete branch after merge.

Incomplete branches: `git rebase main` to bring forward. Prefer rebase over
merge for feature branches.

## Rationale

Mirrors `atlassian-api-tools` ADR 002 for consistency across both repos. The
per-scope numbering means `INI-001/003-foo` always corresponds to
`INI-001`'s third decision, regardless of how many decisions other initiatives
or the repo itself have accumulated.

## Consequences

- `decisions/DECISIONS.md` becomes an index; content lives in individual files.
  Migration applied retroactively for DEC-001 through DEC-006.
- `AGENTS.md` gains a `## Branching` quick-reference section so agents pick up
  the convention without reading this file in full.
- Branches without a new DEC record are valid; the slug describes the change
  rather than a doc number.
