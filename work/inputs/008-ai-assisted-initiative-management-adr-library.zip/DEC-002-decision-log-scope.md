# DEC-002 — Decision log scope

**Date**: 23.03.2026
**Status**: Accepted

## Context

During repo initialisation, the question arose of what belongs in the repo-level
decision log vs. in an individual initiative file vs. in an ADR within INI-003's
architecture documentation initiative.

## Decision

- `decisions/` (this folder): decisions about the repository itself — schema,
  tooling, naming, process conventions.
- Individual INI files: decisions about the scope, approach, and execution of
  that initiative.
- ADRs (in INI-003 / Confluence): architectural decisions about the application
  landscape and engineering standards.

A question that resurfaces more than once, or a convention chosen over a
plausible alternative, warrants a record here.

## Consequences

Three separate decision trails. Agents and contributors must know which log is
appropriate for a given decision.
