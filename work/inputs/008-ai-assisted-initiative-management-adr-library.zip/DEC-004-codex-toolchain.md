# DEC-004 — Toolchain consolidated to Codex in VS Code

**Date**: 23.03.2026
**Status**: Accepted

## Context

The original toolchain split initiative management across three tools: GitHub
Copilot (Intake/Execute), ChatGPT Enterprise browser (Review), and M365 Copilot
(stakeholder comms). The primary motivation for the split was that ChatGPT
Enterprise was only accessible via browser, while in-editor tasks used Copilot.

The OpenAI Codex plugin for VS Code, connected to a ChatGPT Enterprise account,
makes ChatGPT Enterprise accessible directly in the editor with full workspace
file access. This removes the rationale for splitting Intake and Execute onto a
different tool from Review.

## Decision

Codex in VS Code (connected to ChatGPT Enterprise) is the primary tool for all
three modes — Intake, Review, and Execute. With the repo open as a workspace,
Codex can read initiative files and prompt files directly; no `#file:` injection
or paste step is required.

`generate-context.sh` is retained as a fallback for browser-based review
sessions (e.g. when working away from VS Code or sharing context externally).

GitHub Copilot is no longer the primary in-editor agent tool for this repo.

## Consequences

All mode descriptions in `AGENTS.md` reference Codex in VS Code. The
`_prompts/` files remain tool-agnostic in content — they work for any
system-prompt-capable interface. The `generate-context.sh` fallback keeps the
browser workflow viable without maintenance overhead.
