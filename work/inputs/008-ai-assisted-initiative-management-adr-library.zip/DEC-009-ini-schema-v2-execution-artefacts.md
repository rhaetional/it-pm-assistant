# DEC-009 — INI Schema v2: Phases and Staging

**Date**: 2026-03-28
**Status**: Accepted
**Supersedes**: N/A (additive change to existing schema)

---

## Decision

Add a `## Phases` section to the INI schema and rename `## Notes / Next Actions`
to `## Staging`. These two changes are made together because the Jira work item
hierarchy (implemented in `it-pm-tools/publish-initiative`) determines what leaves
the INI file — the schema change and the tool design are the same decision.

---

## Context

As initiatives move from Scoping to Active, the `## Notes / Next Actions` section
accumulates execution artefacts: task lists, phase tracking, status notes.
These belong in Jira, not in the planning document.

The existing schema had no structured place for phases. Phase names were implied
by text in Notes, making programmatic Jira creation impossible without fragile
text parsing. And "Notes / Next Actions" mixed free-form thinking with actionable
tasks — blurring the boundary between planning intent and execution tracking.

---

## Jira Work Item Hierarchy (context)

| INI concept | Jira type | Notes |
|---|---|---|
| Initiative | Epic | One Epic per INI. `customfield_10422` = INI-ID |
| Phase | Story | Child of Epic. One Story per named phase. |
| Staging item | Sub-task | Child of "Phase 0 — Staging" Story (when phases exist), or direct child of Epic (when no phases) |

ITARCH is a team-managed (next-gen) Jira project. In team-managed projects, Tasks
cannot be children of Stories — only Sub-tasks can. Phase Stories and staging
Sub-tasks are both children of the Epic.

---

## Changes

### `## Phases` section (new)

Added after `## Effort Estimate`. Format:

```markdown
## Phases

- Phase 1 — [Name]: [one-line description]
- Phase 2 — [Name]: [one-line description]
```

Rules:
- Section is optional. If no phases, omit or leave empty.
- Each line: `- Phase N — Name: description`
- Phase 0 — Staging is **not** listed here. It is created automatically by
  `publish-initiative` when the `## Staging` section contains unpublished items
  and one or more phases are defined.

### `## Notes / Next Actions` → `## Staging` (rename + semantic change)

The section is renamed and its semantics narrowed:

- **Before**: free-form notes, next actions, phase tracking, context
- **After**: items pending Jira creation only

Items are structured as:
```
- [ ] T-nnn: [task text]
```

After `publish-initiative` runs, published `[ ]` lines are removed and replaced
with a JQL back-reference:
```
<!-- Jira: project = ITARCH AND "Initiative ID[Short text]" = "INI-xxx" -->
```

Non-task prose (context, sub-headings, notes) is preserved verbatim.
Done items `- [x] T-nnn:` are skipped by the tool.

### `**Jira Epics**` field description updated

From: `[SPACE-KEY per phase — populate once created; leave blank until Active]`
To: `[Single Epic key, e.g. ITARCH-42 — written back by publish-initiative; TBD until first run]`

One Epic per INI. Phase grouping is handled by Stories (one Story per Phase entry).
The old "per phase" description reflected an earlier multi-Epic model that was
superseded when DEC-005 clarified the four-layer architecture.

### Status transition gates updated

**Scoping → Active**: "phases/workstreams defined" → "phases defined in `## Phases`
(or explicitly none)"; "Jira Epics created" → "Jira Epic created via
`publish-initiative`".

**Active → Done**: "Notes/Next Actions cleared" → "`## Staging` cleared".

---

## Why Phase 0 — Staging is implicit (not listed in `## Phases`)

Staging items in `## Staging` represent pre-work or backlog not yet assigned to a
phase. Creating a Story for them in Jira groups them visually under the Epic. But
the user should not need to maintain "Phase 0" in the INI file — once all staging
items are published and done, Phase 0 disappears from the INI (the section becomes
a JQL comment), while remaining visible in Jira under its Story.

Keeping Phase 0 implicit:
- Avoids users needing to add a boilerplate Phase 0 entry to every INI file
- Makes the distinction clear: `## Phases` = user-defined named phases;
  `## Staging` = pending backlog managed by the tool

---

## Alternatives considered

### Keep "Notes / Next Actions" and add structure inline

Rejected. The section served two incompatible purposes (free-form planning notes
and actionable task lists). Mixing them makes the tool's parsing fragile and
the semantics ambiguous. Renaming and narrowing is cleaner.

### Use a separate `## Tasks` section

Rejected. "Staging" better communicates the ephemeral nature: items here are
pending publication to Jira. Once published, they leave the file. A permanent
`## Tasks` section would suggest tasks live in the INI long-term, which is
exactly the anti-pattern we are eliminating.

### Phase 0 as an explicit `## Phases` entry

Rejected. See "Why Phase 0 is implicit" above. The tool creates it automatically;
requiring it in the schema adds friction with no benefit.

---

## Related

- `it-pm-tools/tools/publish-initiative/` — implements the API operations
- `it-pm-tools/tools/publish-initiative/decisions/001-subtask-hierarchy.md` — why Sub-task over Task for staging items
- `DEC-005-four-layer-tooling-architecture.md` — planning vs. execution layer boundary
- `DEC-006-jira-project-and-servicenow-ingest.md` — ITARCH project, isolation strategy
- `DEC-008-status-transition-criteria.md` — full gate criteria (updated by this decision)
