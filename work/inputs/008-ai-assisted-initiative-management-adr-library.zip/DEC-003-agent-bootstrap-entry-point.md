# DEC-003 — Bootstrap file as agent entry point

**Date**: 23.03.2026
**Status**: Accepted

## Context

AI agents working in this repo need to orient themselves quickly without reading
all initiative files. A single entry point that describes purpose, schema,
conventions, and open TODOs reduces session startup cost and prevents drift from
established conventions.

## Decision

`AGENTS.md` at repo root is the mandatory first read for any AI agent session.
It is the source of truth for repo structure, schema, and process. Updates to
conventions are reflected here before being applied elsewhere.

## Consequences

`AGENTS.md` must be kept current. Stale bootstrap information is worse than
none — it will cause an agent to confidently apply outdated conventions.
