# DEC-001 — Repository structure: standalone initiatives repo

**Date**: 23.03.2026
**Status**: Accepted

## Context

Initiatives could live as a directory inside a broader repo or as a standalone
repository.

## Decision

Standalone repository. Initiatives are a distinct concern from any codebase or
documentation they touch. Keeping them separate avoids permission, branching,
and context-pollution issues.

## Consequences

Cross-referencing between this repo and other repos (e.g. Confluence content,
application codebases) is by link, not by directory proximity.
