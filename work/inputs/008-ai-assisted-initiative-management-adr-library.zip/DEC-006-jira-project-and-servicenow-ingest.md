# DEC-006 — Jira project confirmed; ServiceNow read-direction approach

**Date**: 25.03.2026
**Status**: Accepted

## Context

DEC-005 established Jira and ServiceNow as layers in the tooling ecosystem but
left the specific Jira project and ServiceNow workaround undefined pending
further investigation.

## Decision

**Jira**: The designated project is **IT-Architecture** (team-managed; admin
rights held). It is a shared team project, so API tooling must be strictly
scoped to issues it creates. Isolation uses three layers: a custom field
`Initiative ID` (e.g. `INI-001`), the label `ini-managed`, and back-references
stored in each INI file's `Jira Epics` field. Full isolation rationale:
`atlassian-api-tools/docs/decisions/003-jira-project-and-isolation.md`.

**ServiceNow**: API access remains unavailable. A ServiceNow saved report
listing the user's projects has been created and can be exported as CSV on
demand. A new tool (`tools/servicenow-ingest/` in `atlassian-api-tools`) reads
that export and produces a local Excel snapshot. This replaces the need for the
`servicenow-stub` push-direction tool in the near term. Full approach:
`atlassian-api-tools/docs/decisions/004-servicenow-ingest.md`.

## Consequences

- Before the first `publish-initiative` run: create the `Initiative ID` custom
  field in the IT-Architecture Jira project (Jira UI → Admin → Project settings
  → Fields).
- The `Jira Epics` field in INI files will carry actual issue keys once an
  initiative is published (format: `ITAR-12, ITAR-13` or similar).
- ServiceNow portfolio state is tracked via a periodically refreshed local Excel
  file, not a live API query.
