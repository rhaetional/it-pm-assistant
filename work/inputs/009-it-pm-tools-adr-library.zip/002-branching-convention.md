# 002 — Branching convention: one branch per decision, `<scope>/<nnn>-<slug>`

## Problem

With multiple small, independent changes landing in quick succession it was
unclear which commits belonged to which decision, and the git history gave no
direct way to navigate back to the reasoning behind a change.

## Context

The repo uses ADRs at two levels:

- `docs/decisions/` — repo-wide decisions
- `tools/<tool>/decisions/` — tool-specific decisions

ADRs are numbered sequentially **within their scope** (per tool, or repo-wide).
During the initial build-out a pattern emerged organically: branch names matched
the decision doc they introduced. This ADR formalises that pattern and records
the quick-reference summary in `CLAUDE.md`.

## Decision

**One branch per cohesive change. The branch is named after the decision doc
it introduces (or the primary change it makes).**

### CLAUDE.md as the behavioral entry point

A dedicated `CLAUDE.md` was added at the repo root to surface behavioral
conventions to every Claude session automatically (Claude Code reads it on
startup). Previously, `REPO_INDEX.md` served a dual purpose: tool inventory
*and* implicit behavioral guide. These are now separated:

- **`CLAUDE.md`** — behavioral instructions: change process, branching
  quick-reference, new-tool checklist, credentials. Updated whenever the
  *way we work* changes.
- **`REPO_INDEX.md`** — factual inventory: tools, lib functions, decision log,
  open issues. Updated whenever the *contents of the repo* change.

`REPO_INDEX.md` retains a one-line pointer to `CLAUDE.md` so sessions that
start there are directed to the right place.

The quick-reference (naming table, example) lives in `CLAUDE.md` so every
Claude session picks it up automatically. This ADR carries the full rationale,
lifecycle, and edge-case rules.

### Naming

```
<scope>/<nnn>-<slug>
```

| Part | Value |
|------|-------|
| `scope` | `docs` for repo-wide decisions; tool folder name for tool-specific ones (e.g. `sync-page-properties`, `confluence-label-sync`) |
| `nnn` | Next unused three-digit number **within that scope** — matches the ADR filename number exactly |
| `slug` | Kebab-case matching the ADR filename; or a descriptive slug if no ADR is created |

Examples:
```
sync-page-properties/005-marker-paragraph-with-preceding-inline-content
confluence-label-sync/001-field-extraction-and-label-diff-strategy
docs/002-branching-convention                              ← this branch
```

Git treats `/` as a namespace separator — GitHub, GitKraken, and SourceTree
group branches into folders automatically.

### Lifecycle

1. **Open** — `git checkout -b <scope>/<nnn>-<slug>` from current `main`.
2. **Work** — code, decision doc, README, and REPO_INDEX all land on the branch.
3. **Merge** — PR or direct `git merge --no-ff` into `main` to preserve the
   branch boundary in the graph.
4. **Delete** — branch deleted after merge; the ADR and commit history are the
   permanent record.

### Incomplete branches

If a branch is not ready to merge when others land, bring it forward with:

```bash
git checkout <scope>/<nnn>-<slug>
git rebase main
```

Rebase is preferred over merge for feature branches — it keeps ancestry linear
and avoids cross-branch merge commits that obscure which change introduced what.

### Branches without a new ADR

Not every change warrants a new ADR (see `CLAUDE.md` change-process rules).
The branch name still follows `<scope>/<nnn>-<slug>`; the slug describes the
change rather than a doc. No ADR entry is required in REPO_INDEX for these
branches, but the commit message should be self-contained.

## Rationale

**Branch name = ADR path** creates a direct navigable link in both directions:
given a branch name you can find the ADR immediately
(`scope/nnn-slug` → `tools/scope/decisions/nnn-slug.md`),
and given an ADR filename you know exactly which branch introduced it.
`git log --oneline --graph` becomes a changelog of decisions, not just commits.

**Per-scope sequence numbers** mean branch numbers always match ADR numbers
within a tool — no global renumbering needed when a new tool is added.
Collisions across scopes are not a problem because the scope prefix
disambiguates.

**CLAUDE.md as entry point** means the naming rule is visible to every Claude
session without having to read the full ADR. The ADR stays as the durable
"why" record; CLAUDE.md carries the actionable summary.

**Delete after merge** keeps the branch list clean. The branch boundary is
visible in the merge-commit graph; the ADR carries the reasoning permanently.

## Evidence

The pattern emerged during the initial build-out (six branches, `001`–`006`)
and proved immediately useful: given a failing page, the branch name pointed
directly to the relevant ADR without any searching.

Those first six branches used a flat global numbering scheme rather than scoped
paths (`001-field-extraction-…` instead of `confluence-label-sync/001-…`).
They are not being renamed retroactively. The scoped convention applies to all
branches opened from this point forward.

## Review Triggers

- More than one person works on the repo simultaneously — evaluate a PR review
  step and branch protection before merge.
- Branches start accumulating many commits — consider splitting into smaller
  units.

## Affected Files

- `docs/decisions/002-branching-convention.md` — new (this file)
- `CLAUDE.md` — branching quick-reference added under `## Branching`
- `docs/REPO_INDEX.md` — 002 entry added; header updated to point to `CLAUDE.md`; open issue resolved
